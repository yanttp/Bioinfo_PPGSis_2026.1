# 🧬 Bioinformática — PPGSIS/UFC 2026/1

**Docente:** Dr. Yan Torres  
**Programa:** Sistemática, Uso e Conservação da Biodiversidade — UFC  
**Período:** 15/06 a 04/07/2026 · 08h00–12h00  
**Carga horária:** 40h (20h teórica + 20h prática)

---

## Módulos

| # | Módulo | Ferramentas principais |
|---|--------|----------------------|
| 1 | Ambiente computacional (Linux + Git + Conda) | bash, git, mamba |
| 2 | QC e pré-processamento de reads (NGS) | FastQC, MultiQC, fastp |
| 3 | Montagem *de novo* de genomas | SPAdes, QUAST, BUSCO, Prokka |
| 4 | Metagenômica (amplicons 16S) | QIIME2, phyloseq, vegan |
| 5 | Identificação de variantes (RAD-seq / SNP Calling) | Stacks, VCFtools, adegenet |

---

## Como começar (alunos)

👉 **Leia o [TUTORIAL_ALUNOS.md](TUTORIAL_ALUNOS.md) antes de qualquer coisa.**

O tutorial explica como:
1. Fazer fork deste repositório
2. Criar seu Codespace (2-core, gratuito)
3. Verificar a instalação
4. Usar Git para salvar e entregar o trabalho

---

## Estrutura do repositório

```
├── dados/              ← datasets sintéticos e tutoriais
├── scripts/            ← scripts de exemplo por módulo
├── projetos/           ← trabalhos finais dos grupos
├── figuras/            ← figuras geradas nas análises
├── relatorio/          ← template do artigo final
├── .devcontainer/      ← configuração automática do ambiente
├── TUTORIAL_ALUNOS.md  ← guia de configuração (leia primeiro!)
└── README.md           ← este arquivo
```

---

## Avaliação

O projeto final consiste em:
- **Análise de dados** em uma das três linhas: montagem de genomas, metagenômica ou SNP calling
- **Artigo** no formato IMRD (Introdução, Métodos, Resultados, Discussão) — ~3–5 páginas
- **Apresentação oral** de 10 minutos (03/07/2026)
- **Entrega:** via Pull Request neste repositório até 02/07/2026 às 23:59

Grupos: duplas ou trios.

---

## Citação dos softwares

Ao escrever o artigo, cite os softwares utilizados. Os arquivos `scripts/*/referencias.md` contêm as referências corretas para cada ferramenta.

---

*Universidade Federal do Ceará · 2026*
